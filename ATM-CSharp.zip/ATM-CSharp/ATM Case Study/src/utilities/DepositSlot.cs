﻿namespace ATM_Case_Study
{
    public class DepositSlot
    {
        public bool IsEnvelopeReceived { get { return true; } }
    }
}
