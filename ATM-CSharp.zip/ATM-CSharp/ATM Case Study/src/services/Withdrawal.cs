﻿using static System.Console;
using static System.Threading.Thread;
using ATM_Case_Study.src.ui;

namespace ATM_Case_Study
{
    public class Withdrawal : Transaction
    {
        ShowOp _showOp = new ShowOp();

        private decimal _amount;
        private Keypad _keypad;
        private CashDispenser _cashDispenser;
       
        private const int CANCELED = 6;

        public Withdrawal(int userAccount, Screen atmScreen,
              Account account, Keypad atmKeypad, CashDispenser atmCashDispenser)
            : base(userAccount, account, atmScreen)
        {
            _keypad = atmKeypad;
            _cashDispenser = atmCashDispenser;
        }

        private int DisplayMenuOfAmounts()
        {
            int userChoice = 0;

            int[] amounts = { 0, 20, 40, 60, 100, 200 };

            while (userChoice == 0)
            {
                Clear();
                _showOp.withdrawalMenu();

                int input = _keypad.GetInput();

                switch (input)
                {
                    case 1: // if the user chose a withdrawal amount 
                    case 2: // (i.e., chose option 1, 2, 3, 4 or 5), return the
                    case 3: // corresponding amount from amounts array
                    case 4:
                    case 5:
                        userChoice = amounts[input]; // save user's choice
                        break;
                    case CANCELED: // the user chose to cancel
                        userChoice = CANCELED; // save user's choice
                        break;
                    default: // the user did not enter a value from 1-6
                        _showOp.selectError();
                        Sleep(2000);
                        break;
                }
            }

            return userChoice;
        }

        public override void Execute()
        {
            bool isCashDispensed = false;
            decimal availableBalance;

            Account account = new Account(0, 0, 0, 0);

            do
            {
                _amount = (decimal)DisplayMenuOfAmounts();

                if (_amount != CANCELED)
                {
                    availableBalance = account.getAvailableBalance(AccountNumber);
                    if (_amount <= availableBalance)
                    {
                        if (_cashDispenser.IsSufficiantCashAvailable(_amount))
                        {
                            account.Debit(AccountNumber, _amount);
                            _cashDispenser.DispenseCash(_amount);
                            isCashDispensed = true;

                            _showOp.withdrawaSuccessful();
                        }
                        else
                            _showOp.smallAmount();
                    }
                    else
                        _showOp.withdrawaUnsuccessful();
                    Sleep(3000);
                }
                else
                {
                    _showOp.Cancel();
                    Sleep(3000);
                    return;
                }
            } while (!isCashDispensed);
        }
    }
}
