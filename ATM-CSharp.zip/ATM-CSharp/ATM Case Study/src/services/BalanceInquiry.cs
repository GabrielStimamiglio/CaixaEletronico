﻿using static System.Threading.Thread;
using ATM_Case_Study.src.ui;

namespace ATM_Case_Study
{
    public class BalanceInquiry : Transaction
    {
        ShowOp _showOp = new ShowOp();

        public BalanceInquiry(int userAccountNumber, Screen atmScreen, Account account) 
            : base(userAccountNumber, account, atmScreen) { }

        public override void Execute()
        {
            Account account = base.account;
            Screen screen = base.Screen;

            decimal availableBalance = account.getAvailableBalance(AccountNumber);
            decimal totalBalance = account.getTotalBalance(AccountNumber);

            _showOp.balanceInfo();
            _showOp.availableBalance();
            screen.DisplayDollarAmount(availableBalance);
            _showOp.totalBalance();
            screen.DisplayDollarAmount(totalBalance);
            screen.DisplayMessageLine(string.Empty);

            Sleep(5000);
        }
    }
}