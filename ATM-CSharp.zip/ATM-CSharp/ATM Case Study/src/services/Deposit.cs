﻿using static System.Threading.Thread;
using ATM_Case_Study.src.ui;

namespace ATM_Case_Study
{
    public class Deposit : Transaction
    {
        ShowOp _showOp = new ShowOp();

        private decimal _amount;
        private Keypad _keypad;
        private DepositSlot _depositSlot;
        private const int CANCELED = 0;

        public Deposit(int userAccountNumber, Screen atmScreen,
            Account account, Keypad atmKeypad, DepositSlot atmDepositSlot)
            : base(userAccountNumber, account, atmScreen)
        {
            _keypad = atmKeypad;
            _depositSlot = atmDepositSlot;
        }

        public override void Execute()
        {
            _amount = PromptForDepositAmount();

            if (_amount != CANCELED)
            {
                _showOp.depositEnvelope();
                Screen.DisplayDollarAmount(_amount);
                _showOp.depositSlot();

                bool envelopeReceived = _depositSlot.IsEnvelopeReceived;

                if (envelopeReceived)
                {
                    _showOp.depositReceived();

                    account.Credit(AccountNumber, _amount);
                }
                else
                    _showOp.depositNotReceived();
            }
            else
                _showOp.Cancel();

            Sleep(3000);
        }

        private decimal PromptForDepositAmount()
        {
            _showOp.depositCents();
            int input = _keypad.GetInput();
            return input == CANCELED ? CANCELED : input / 100M;
        }
    }
}

