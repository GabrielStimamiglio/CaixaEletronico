﻿namespace ATM_Case_Study
{
    public class BankDatabase
    {
        private Account[] _accounts;

        public BankDatabase()
        {
            _accounts = new Account[2]; // just 2 accounts for testing
            _accounts[0] = new Account(12345, 54321, 1000, 1200);
            _accounts[1] = new Account(98765, 56789, 200, 200);
        }

        public Account[] getAllAccount()
        {
            return _accounts;  
        }

    }
}