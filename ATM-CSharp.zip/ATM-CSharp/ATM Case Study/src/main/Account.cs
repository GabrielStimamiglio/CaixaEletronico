﻿namespace ATM_Case_Study
{
    public class Account
    {
        

        public int AccountNumber { get; private set; }
        public decimal AvailableBalance { get; private set; }
        private int Pin { get; set; }
        public decimal TotalBalance { get; private set; }
        
        public Account(int accountNumber, int pin, decimal totalBalance, decimal availableBalance)
        {
            AccountNumber = accountNumber;
            Pin = pin;
            TotalBalance = totalBalance;
            AvailableBalance = availableBalance;
            
        }

        public void Credit(decimal amount) => TotalBalance += amount;

        public void Debit(decimal amount)
        {
            AvailableBalance -= amount;
            TotalBalance -= amount;
        }

        public bool ValidatePin(int userPin) => userPin == Pin;
   
        public Account GetAccount(int accountNumber)
        {
            BankDatabase bd = new BankDatabase();

            foreach (Account currentAccount in bd.getAllAccount())
            {
                
                if (currentAccount.AccountNumber == accountNumber)
                    return currentAccount;
            }

            return null; 
        }
        public bool AuthenticateAccount(int userAccountNumber, int userPin)
        {
           
            Account userAccount = GetAccount(userAccountNumber);
            return userAccount != null ? userAccount.ValidatePin(userPin) : false;
        }

        public void Credit(int userAccountNumber, decimal amount) => GetAccount(userAccountNumber).Credit(amount);
        public void Debit(int userAccountNumber, decimal amount) => GetAccount(userAccountNumber).Debit(amount);
        public decimal getAvailableBalance(int userAccountNumber) => GetAccount(userAccountNumber).AvailableBalance;
        public decimal getTotalBalance(int userAccountNumber) => GetAccount(userAccountNumber).TotalBalance;
    }

}