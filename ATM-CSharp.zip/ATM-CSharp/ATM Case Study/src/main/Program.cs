﻿using ATM_Case_Study.src.ui;

namespace ATM_Case_Study
{
    class Program
    {
        static void Main(string[] args)
        {
            ATM atm = new ATM();
            atm.Run();
        }
    }
}
