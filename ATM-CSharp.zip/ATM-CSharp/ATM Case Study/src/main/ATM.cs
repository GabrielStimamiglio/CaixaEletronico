﻿using ATM_Case_Study.src.ui;
using static System.Console;
using static System.Threading.Thread;

namespace ATM_Case_Study
{
    /// <summary>
    /// constants corresponding to main menu options
    /// </summary>
    internal enum MenuOption
    {
        BalanceInquiry = 1,
        Withdrawal = 2,
        Deposit = 3,
        Exit = 4
    };

    public class ATM
    {
        /// <summary>
        /// account information database
        /// </summary>
        private Account _account;
        /// <summary>
        /// ATM's cash dispenser
        /// </summary>
        private CashDispenser _cashDispenser;
        /// <summary>
        /// current user's account number
        /// </summary>
        private int _currentAccountNumber;
        /// <summary>
        /// ATM's deposit slot
        /// </summary>
        private DepositSlot _depositSlot;
        /// <summary>
        /// ATM's keypad
        /// </summary>
        private Keypad _keypad;
        /// <summary>
        /// ATM's screen
        /// </summary>
        private Screen _screen;
        /// <summary>
        /// whether user is authenticated
        /// </summary>
        private ShowOp _showOp;

        private bool _userAuthenticated;

        /// <summary>
        /// no-argument ATM constructor initializes instance variables
        /// </summary>
        public ATM()
        {
            _userAuthenticated = false;
            _currentAccountNumber = 0;
            _depositSlot = new DepositSlot();
            _keypad = new Keypad();
            _screen = new Screen();
            _cashDispenser = new CashDispenser();
            _account = new Account(0,0,0,0);
            _showOp = new ShowOp();
        }

        private void AuthenticateUser()
        {
            Clear();
            _showOp.login(); //Insert Account Number
            int accountNumber = _keypad.GetInput();
            _showOp.password(); //Insert Pin
            int pinCode = _keypad.GetInput();
            
            Account account = new Account(0, 0, 0, 0);

            _userAuthenticated = account.AuthenticateAccount(accountNumber, pinCode);
            if (_userAuthenticated)
                _currentAccountNumber = accountNumber; // Provide access to account if authentication is correct.
            else
                _showOp.erroLogin(); // Try again if the authentication is incorrect.

            Sleep(3000);
        }

        private Transaction CreateTransaction(MenuOption type)
        {
            Transaction temp = null;

            switch (type)
            {
                case MenuOption.BalanceInquiry:
                    temp = new BalanceInquiry(_currentAccountNumber, _screen, _account.GetAccount(_currentAccountNumber));
                    break;
                case MenuOption.Withdrawal:
                    temp = new Withdrawal(_currentAccountNumber, _screen, _account.GetAccount(_currentAccountNumber), _keypad, _cashDispenser);
                    break;
                case MenuOption.Deposit:
                    temp = new Deposit(_currentAccountNumber, _screen, _account.GetAccount(_currentAccountNumber), _keypad, _depositSlot);
                    break;
            }

            return temp;
        }

        private void PerformTransactions()
        {
            // local variable to store transaction currently being processed
            Transaction currentTransaction = null;

            bool isUserExited = false; // user has not chosen to exit

            // loop while user has not chosen option to exit system
            while (!isUserExited)
            {
                Clear();

                MenuOption menuSelect = DisplayMainMenu();

                switch (menuSelect)
                {
                    case MenuOption.BalanceInquiry:
                    case MenuOption.Withdrawal:
                    case MenuOption.Deposit:
                        currentTransaction = CreateTransaction(menuSelect);
                        currentTransaction.Execute();
                        break;
                    case MenuOption.Exit:
                        _showOp.exit(); // Exiting the system...
                        isUserExited = true;
                        Sleep(3000);
                        Clear();
                        break;
                    // Try again if you enter a value other than the enum values, regardless of the GetInput method.
                    default:
                        _showOp.selectError(); // You did not enter a valid selection. Try again.
                        break;
                }
            }
        }

        private MenuOption DisplayMainMenu()
        {
            _showOp.mainMenu();// Menu
            
            MenuOption menuSelect = (MenuOption)_keypad.GetInput();
            return menuSelect;
        }

        public void Run()
        {
            // welcome and authenticate user; perform transactions
            while (true)
            {
                while (!_userAuthenticated) // loop while user is not yet authenticated
                {
                    _showOp.welcome();//Welcome
                    AuthenticateUser();
                }

                PerformTransactions(); // user is now authenticated
                _userAuthenticated = false;
                _currentAccountNumber = 0;
                _showOp.goodbye(); //Thank you! Goodbye!
                Sleep(2000);
            }
        }
    }
}
