﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Threading.Thread;

namespace ATM_Case_Study.src.ui
{
    class ShowOp
    {
       Screen _screen = new Screen();

        public ShowOp()
        {

        }

        public void mainMenu()
        {
            _screen.DisplayMessage("MAIN MENU: " +
                                   "\n\n1 - View my balance" +
                                   "\n2 - Withdraw cash" +
                                   "\n3 - Deposit funds" +
                                   "\n4 - Exit" +
                                   "\nPlease enter a choise: ");
        }
        public void login()
        {
            _screen.DisplayMessageLine("Please enter your account number: ");
        }
        public void password()
        {
            _screen.DisplayMessageLine("Enter your PIN: ");
        }
        public void erroLogin()
        {
            _screen.DisplayMessageLine("Invalid account number or PIN. Please try again. ");
        }
        public void exit()
        {
            _screen.DisplayMessageLine("Exiting the system...");
        }
        public void selectError()
        {
            _screen.DisplayMessageLine("You did not enter a valid selection. Try again.");
        }
        public void welcome()
        {
            _screen.DisplayMessageLine("Welcome!");
        }
        public void goodbye()
        {
            _screen.DisplayMessageLine("Thank you! Goodbye!");
        }
        public void withdrawalMenu()
        {
            _screen.DisplayMessageLine("\nWITHDRAWAL MENU: ");
            _screen.DisplayMessageLine("1 - $20");
            _screen.DisplayMessageLine("2 - $40");
            _screen.DisplayMessageLine("3 - $60");
            _screen.DisplayMessageLine("4 - $100");
            _screen.DisplayMessageLine("5 - $200");
            _screen.DisplayMessageLine("6 - Cancel transaction");
            _screen.DisplayMessage("\nChoose a withdrawal amount: ");
        }
        public void withdrawaSuccessful()
        {
            _screen.DisplayMessageLine("\nYour cash has been dispensed. Please take your cash now.");
        }
        public void smallAmount()
        {
            _screen.DisplayMessageLine("\nInsufficient cash available in the ATM.\n\nPlease choose a smaller amount.");
        }
        public void withdrawaUnsuccessful()
        {
            _screen.DisplayMessage("\nInsufficient funds in your account.\n\nPlease choose a smaller amount.");
        }
        public void Cancel()
        {
            _screen.DisplayMessageLine("\nCancelling transaction...");
        }
        public void balanceInfo()
        {
            _screen.DisplayMessageLine("\nBalance Information:");
        }
        public void availableBalance()
        {
            _screen.DisplayMessage(" - Available balance: ");
        }
        public void totalBalance()
        {
            _screen.DisplayMessage("\n - Total balance:     ");
        }
        public void depositEnvelope()
        {
            _screen.DisplayMessage("Please insert a deposit envelope containing ");
        }
        public void depositSlot()
        {
            _screen.DisplayMessageLine(" in the deposit slot.");
        }
        public void depositReceived()
        {
            _screen.DisplayMessageLine(
                        "Your envelope has been received.\n" +
                        "The money just deposited will not be available " +
                        "until we \nverify the amount of any " +
                        "enclosed cash, and any enclosed checks clear.");
        }
        public void depositNotReceived()
        {
            _screen.DisplayMessageLine("You did not insert an envelope, so the ATM has canceled your transaction.");
        }
        public void depositCents()
        {
            _screen.DisplayMessageLine("Please input a deposit amount in CENTS (or 0 to cancel): ");
        }
        
    }
}
